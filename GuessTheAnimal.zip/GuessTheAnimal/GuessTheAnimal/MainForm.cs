﻿//13/10/2017    - Graeme Thomas Initial Development
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Configuration;
using System.Linq;

namespace GuessTheAnimal
{
    public partial class frmMain : Form
    {
        Dictionary<string, string> AnimalItems = new Dictionary<string, string>(); //Initialise
        bool blnNewAnimal = false;
        bool blnNewColour = false;
        bool blnNewSound = false;
        bool blnNewFeature = false;
        public frmMain()
        {
            InitializeComponent();
            GetDataFromConfig(); //Load data from the config file
            //Add Image and resize
            pbSound.Visible = true;
            pbSound.Image = Properties.Resources.ArrowLeft;
            pbSound.SizeMode = PictureBoxSizeMode.Zoom;
            //Set focus for game
            txtFocus.Text = "2";
            MessageBox.Show("Please choose an animal from the list on the left and when ready press start!");
        }

        //---------------------------------
        //Functions
        //---------------------------------
        private bool AddDataToConfig(string key, string value)
        {
            try
            {
                // Open App.Config of executable
                Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
                //Add Key and Value
                config.AppSettings.Settings.Add(key, value);
                //Save File
                config.Save(ConfigurationSaveMode.Modified); 
                //Refresh
                ConfigurationManager.RefreshSection("appSettings");
                return true;
            }
            catch 
            {
                return false;
            }
        }
        private void GetDataFromConfig()
        {
            try
            {
                foreach (string key in ConfigurationManager.AppSettings)
                {
                    string value = ConfigurationManager.AppSettings[key];
                    switch (value)
                    {
                        case "animalFeature":
                            cboFeature.Items.Add(key);
                            break;
                        case "animalColour":
                            cboColour.Items.Add(key);
                            break;
                        case "animalSound":
                            cboSound.Items.Add(key);
                            break;
                        default:
                            lbAnimals.Items.Add(key); //Add to list box
                            AnimalItems.Add(key, value); //Add to dictionary
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private List<string> SearchDictionary(string strSearchValue)
        {
            try
            {
                //Search for values
                List<string> lstAnimals = new List<string>();
                var result = AnimalItems.Where(entry => entry.Value.Contains(strSearchValue))
                    .Select(item => item.Key);

                //Clear listbox before entering new list
                lbAnimals.Items.Clear();

                //Loop
                foreach (var key in result)
                {
                    lstAnimals.Add(key);
                    lbAnimals.Items.Add(key);
                }
                
                //Return Values
                return lstAnimals;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            
        }
        private void ResetForm()
        {
            pbName.Visible = false;
            pbColour.Visible = false;
            pbFeature.Visible = false;
            pbSound.Visible = false;
        }

        private int GetNextIndex(int intComboItem)
        {
            Random random = new Random();
            int newIndex = -1;

            try
            {
                if (intComboItem == 1)
                {
                    do
                    {
                        newIndex = random.Next(1,cboSound.Items.Count);
                    } while (newIndex == cboSound.SelectedIndex && cboSound.Items.Count > 1);
                }
                else if (intComboItem == 2)
                {
                    do
                    {
                        newIndex = random.Next(1,cboFeature.Items.Count);
                    } while (newIndex == cboFeature.SelectedIndex && cboFeature.Items.Count > 1);
                }
                else if (intComboItem == 3)
                {
                    do
                    {
                        newIndex = random.Next(1,cboColour.Items.Count);
                    } while (newIndex == cboColour.SelectedIndex && cboColour.Items.Count > 1);
                }
                else if (intComboItem == 4)
                {
                    do
                    {
                        newIndex = random.Next(1, lbAnimals.Items.Count);
                    } while (newIndex == lbAnimals.SelectedIndex && lbAnimals.Items.Count > 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return newIndex;
        }

        private static string FirstCharToUpper(string input)
        {
            return input.First().ToString().ToUpper() + input.Substring(1);
        }

        private void SendMessage(string strMessage, int intControlNo)
        {
            int intIndex = -1;
            try
            {
                DialogResult dialogResult = MessageBox.Show(strMessage, "Guess", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    if (intControlNo ==0) //Guess correct
                    {
                        ResetForm();
                        txtName.Text = "";
                        txtName.Enabled = false;
                        cboSound.Enabled = true;
                        cboSound.Text = "";
                        cboSound.Items.Clear();
                        cboFeature.Enabled = false;
                        cboFeature.Text = "";
                        cboFeature.Items.Clear();
                        cboColour.Text = "";
                        cboColour.Enabled = false;
                        cboColour.Items.Clear();
                        lbAnimals.Items.Clear();
                        AnimalItems.Clear(); //Clear
                        GetDataFromConfig(); //Load data from the config file

                    }
                    else if (intControlNo == 1) //Sound
                    {
                        //Get Index for random selection of first combo box
                        intIndex = GetNextIndex(1);
                        cboSound.SelectedIndex = intIndex;
                    }
                    else if (intControlNo == 2) //Feature
                    {
                        //Get Index for random selection of second combo box
                        intIndex = GetNextIndex(2);
                        cboFeature.SelectedIndex = intIndex;
                    }
                    else if (intControlNo == 3) //Colour
                    {
                        //Get Index for random selection of third combo box
                        intIndex = GetNextIndex(3);
                        cboColour.SelectedIndex = intIndex;
                    }

                }
                else if (dialogResult == DialogResult.No)
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //----------------------------------------------------
        private void ClearLists()
        {
            AnimalItems.Clear();
            lbAnimals.Items.Clear();
            cboSound.Items.Clear();
            cboFeature.Items.Clear();
            cboColour.Items.Clear();
        }

        //----------------------------------------------------
        private void btnGuess_Click(object sender, EventArgs e)
        {
            try
            {
                ResetForm();
                ClearLists();
                GetDataFromConfig();
                txtFocus.Text = "2";
                txtName.Text = "";
                txtName.Enabled = false;
                cboSound.Text = "";
                cboSound.Enabled = true;
                cboFeature.Text = "";
                cboFeature.Enabled = false;
                cboColour.Text = "";
                cboColour.Enabled = false;
                SendMessage("I am going to guess the sound your chosen animal would make!", 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //----------------------------------------------------
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string strValue = "";
            try
            {
                ResetForm();
                //----------------------------------------------------------
                if (txtName.Text == "")
                {
                    MessageBox.Show("Please enter a name!");
                    return;
                }
                else if (cboSound.Text == "")
                {
                    MessageBox.Show("Please enter a sound!");
                    return;
                }
                else if (cboFeature.Text == "")
                {
                    MessageBox.Show("Please enter a feature!");
                    return;
                }
                else if (cboColour.Text == "")
                {
                    MessageBox.Show("Please enter a colour!");
                    return;
                }
                //----------------------------------------------------------
                //Check Name is new
                //----------------------------------------------------------
                if (lbAnimals.Items.Contains(txtName.Text))
                {
                    blnNewAnimal = false;
                }
                else
                {
                    blnNewAnimal = true;
                }

                if (cboSound.Items.Contains(cboSound.Text))
                {
                    blnNewSound = false;
                }
                else
                {
                    blnNewSound = true;
                    cboSound.Items.Add(cboSound.Text);
                }

                if (cboColour.Items.Contains(cboColour.Text))
                {
                    blnNewColour = false;
                }
                else
                {
                    blnNewColour = true;
                    cboColour.Items.Add(cboColour.Text);
                }

                if (cboFeature.Items.Contains(cboFeature.Text))
                {
                    blnNewFeature = false;
                }
                else
                {
                    blnNewFeature = true;
                    cboFeature.Items.Add(cboFeature.Text);
                }
                //----------------------------------------------------------
                //Add New Items to config file
                //----------------------------------------------------------
                if (blnNewSound)
                {
                    strValue = cboSound.Text.ToLower();
                    strValue = FirstCharToUpper(strValue);
                    AddDataToConfig(strValue, "animalSound"); //Add sound                
                }

                if (blnNewFeature)
                {
                    strValue = cboFeature.Text.ToLower();
                    strValue = FirstCharToUpper(strValue);
                    AddDataToConfig(strValue, "animalFeature"); //Add feature               
                }

                if (blnNewColour)
                {
                    strValue = cboColour.Text.ToLower();
                    strValue = FirstCharToUpper(strValue);
                    AddDataToConfig(strValue, "animalColour"); //Add colour              
                }

                if (blnNewAnimal)
                {
                    if (AddDataToConfig(txtName.Text, cboFeature.Text + "," + cboSound.Text + "," + cboColour.Text)) //Call function
                    {
                        MessageBox.Show("Animal has been added!");
                    }
                    else
                    {
                        MessageBox.Show("There was an error and the animal entered has not been added!");
                    }
                }
                
                //Reset Values
                blnNewAnimal = false;
                blnNewColour = false;
                blnNewFeature = false;
                blnNewSound = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        //----------------------------------------------------
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close(); //Close form
        }
        //----------------------------------------------------
        private void btnYes_Click(object sender, EventArgs e)
        {
            List<string> lstValues = new List<string>();
            int intIndex;

            try
            {
                if (txtFocus.Text == "1") //Game Finished if correct
                {
                    pbName.Visible = true;
                    pbName.Image = Properties.Resources.Correct;
                    pbName.SizeMode = PictureBoxSizeMode.Zoom;
                    SendMessage("The animal has been identified as a(n)" + txtName.Text + ". Game Over!", 0);
                    txtFocus.Text = "2";
                }
                else if (txtFocus.Text == "2") //Sound
                {
                    pbSound.Visible = true;
                    pbSound.Image = Properties.Resources.Correct;
                    pbSound.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "3";
                    cboFeature.Enabled = true;
                    lstValues = SearchDictionary(cboSound.Text);
                    //If count is one then we have the animal
                    if (lstValues != null)
                    {
                        if (lstValues.Count == 1)
                        {
                            SendMessage("Is the animal you are thinking of a(n) " + lstValues.First() + "?", 0);
                        }
                        else
                        {
                            //Random selection on next control
                            intIndex = GetNextIndex(2);
                            cboFeature.SelectedIndex = intIndex;
                        }
                    }
                }
                else if (txtFocus.Text == "3") //Feature
                {
                    pbFeature.Visible = true;
                    pbFeature.Image = Properties.Resources.Correct;
                    pbFeature.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "4";
                    cboColour.Enabled = true;
                    lstValues = SearchDictionary(cboFeature.Text + "," + cboSound.Text); 
                    if (lstValues != null)
                    {
                        if (lstValues.Count == 1)
                        {
                            SendMessage("Is the animal you are thinking of a(n) " + lstValues.First() + "?", 0);
                        }
                        else
                        {
                            //Random selection on next control
                            intIndex = GetNextIndex(3);
                            cboColour.SelectedIndex = intIndex;
                        }
                    }
                }
                else if (txtFocus.Text == "4") //Colour
                {
                    pbColour.Visible = true;
                    pbColour.Image = Properties.Resources.Correct;
                    pbColour.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "1";
                    txtName.Enabled = true;
                    lstValues = SearchDictionary(cboFeature.Text + "," + cboSound.Text + ","+ cboColour.Text);
                    if (lstValues != null)
                    {
                        if (lstValues.Count == 1)
                        {
                            SendMessage("Is the animal you are thinking of a(n) " + lstValues.First() + "?", 0);
                        }
                        else
                        {
                            intIndex = GetNextIndex(4);
                            txtName.Text = lbAnimals.Items[intIndex].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //----------------------------------------------------
        private void btnNo_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFocus.Text == "1") 
                {
                    pbName.Visible = true;
                    pbName.Image = Properties.Resources.Incorrect;
                    pbName.SizeMode = PictureBoxSizeMode.Zoom;
                    lbAnimals.Items.Remove(txtName.Text);
                    txtFocus.Text = "1";
                    if (lbAnimals.Items.Count == 1)
                    {
                        txtName.Text = lbAnimals.Items[0].ToString();
                    }
                    else if (lbAnimals.Items.Count > 1)
                    {
                        int intIndex = -1;
                        intIndex = GetNextIndex(4);
                        txtName.Text = lbAnimals.Items[intIndex].ToString();
                    }
                    else
                    {
                        txtName.Text = "";
                    }
                     
                }
                else if (txtFocus.Text == "2") //Sound
                {
                    pbSound.Visible = true;
                    pbSound.Image = Properties.Resources.Incorrect;
                    pbSound.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "2";
                    cboSound.Items.Remove(cboSound.SelectedItem);
                    cboSound.Text = "";
                    SendMessage("I have chosen the wrong sound and would like to try again!", 1);
                }
                else if (txtFocus.Text == "3") //Feature
                {
                    pbFeature.Visible = true;
                    pbFeature.Image = Properties.Resources.Incorrect;
                    pbFeature.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "3";
                    cboFeature.Items.Remove(cboSound.SelectedItem);
                    cboFeature.Text = "";
                    SendMessage("I have chosen the wrong feature and would like to try again!", 2);
                }
                else if (txtFocus.Text == "4") //Colour
                {
                    pbColour.Visible = true;
                    pbColour.Image = Properties.Resources.Incorrect;
                    pbColour.SizeMode = PictureBoxSizeMode.Zoom;
                    txtFocus.Text = "4";
                    cboColour.Items.Remove(cboSound.SelectedItem);
                    cboColour.Text = "";
                    SendMessage("I have chosen the wrong colour and would like to try again!", 3);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboColour_Leave(object sender, EventArgs e)
        {
            if (cboColour.Text != "")
            {
                ComboBox cb = (ComboBox)sender;
                if (cb.Items.Contains(cb.Text))
                {
                    blnNewColour = false;
                }
                else
                {
                    blnNewFeature = true;
                }
            }
        }

        private void cboFeature_Leave(object sender, EventArgs e)
        {
            if (cboFeature.Text != "")
            {
                ComboBox cb = (ComboBox)sender;
                if (cb.Items.Contains(cb.Text))
                {
                    blnNewFeature = false;
                }
                else
                {
                    blnNewFeature = true;
                }
            }
        }

        private void cboSound_Leave(object sender, EventArgs e)
        {
            if (cboSound.Text != "")
            {
                ComboBox cb = (ComboBox)sender;
                if (cb.Items.Contains(cb.Text))
                {
                    blnNewSound = false;
                }
                else
                {
                    blnNewSound = true;
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
            txtName.Enabled = true;
            txtName.Text = "";
            cboColour.Enabled = true;
            cboColour.Text = "";
            cboFeature.Enabled = true;
            cboFeature.Text = "";
            cboSound.Enabled = true;
            cboSound.Text = "";
            btnAdd.Enabled = true;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                SendMessage("I am going to guess the sound your chosen animal would make!",1);

            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //----------------------------------------------------
    }
}
