﻿namespace GuessTheAnimal
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlAnimal = new System.Windows.Forms.Panel();
            this.lbAnimals = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboColour = new System.Windows.Forms.ComboBox();
            this.pbColour = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboFeature = new System.Windows.Forms.ComboBox();
            this.pbFeature = new System.Windows.Forms.PictureBox();
            this.gbSound = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboSound = new System.Windows.Forms.ComboBox();
            this.pbSound = new System.Windows.Forms.PictureBox();
            this.gbName = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.pbName = new System.Windows.Forms.PictureBox();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtFocus = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnGuess = new System.Windows.Forms.Button();
            this.pnlYesNo = new System.Windows.Forms.Panel();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnYes = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.pnlAnimal.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbColour)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFeature)).BeginInit();
            this.gbSound.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSound)).BeginInit();
            this.gbName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbName)).BeginInit();
            this.pnlControls.SuspendLayout();
            this.pnlYesNo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAnimal
            // 
            this.pnlAnimal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAnimal.Controls.Add(this.lbAnimals);
            this.pnlAnimal.Controls.Add(this.groupBox2);
            this.pnlAnimal.Controls.Add(this.groupBox1);
            this.pnlAnimal.Controls.Add(this.gbSound);
            this.pnlAnimal.Controls.Add(this.gbName);
            this.pnlAnimal.Location = new System.Drawing.Point(12, 12);
            this.pnlAnimal.Name = "pnlAnimal";
            this.pnlAnimal.Size = new System.Drawing.Size(1275, 779);
            this.pnlAnimal.TabIndex = 0;
            // 
            // lbAnimals
            // 
            this.lbAnimals.FormattingEnabled = true;
            this.lbAnimals.ItemHeight = 31;
            this.lbAnimals.Location = new System.Drawing.Point(15, 16);
            this.lbAnimals.Name = "lbAnimals";
            this.lbAnimals.Size = new System.Drawing.Size(447, 748);
            this.lbAnimals.Sorted = true;
            this.lbAnimals.TabIndex = 12;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cboColour);
            this.groupBox2.Controls.Add(this.pbColour);
            this.groupBox2.Location = new System.Drawing.Point(468, 565);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(802, 161);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(564, 32);
            this.label2.TabIndex = 11;
            this.label2.Text = "Does the animal have the followimg colour?";
            // 
            // cboColour
            // 
            this.cboColour.Enabled = false;
            this.cboColour.FormattingEnabled = true;
            this.cboColour.Items.AddRange(new object[] {
            ""});
            this.cboColour.Location = new System.Drawing.Point(22, 97);
            this.cboColour.Name = "cboColour";
            this.cboColour.Size = new System.Drawing.Size(425, 39);
            this.cboColour.Sorted = true;
            this.cboColour.TabIndex = 2;
            this.cboColour.Leave += new System.EventHandler(this.cboColour_Leave);
            // 
            // pbColour
            // 
            this.pbColour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbColour.Location = new System.Drawing.Point(641, 55);
            this.pbColour.Name = "pbColour";
            this.pbColour.Size = new System.Drawing.Size(100, 81);
            this.pbColour.TabIndex = 6;
            this.pbColour.TabStop = false;
            this.pbColour.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cboFeature);
            this.groupBox1.Controls.Add(this.pbFeature);
            this.groupBox1.Location = new System.Drawing.Point(472, 379);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(802, 161);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(575, 32);
            this.label1.TabIndex = 10;
            this.label1.Text = "Does the animal have the followimg feature?";
            // 
            // cboFeature
            // 
            this.cboFeature.Enabled = false;
            this.cboFeature.FormattingEnabled = true;
            this.cboFeature.Items.AddRange(new object[] {
            ""});
            this.cboFeature.Location = new System.Drawing.Point(18, 98);
            this.cboFeature.Name = "cboFeature";
            this.cboFeature.Size = new System.Drawing.Size(425, 39);
            this.cboFeature.Sorted = true;
            this.cboFeature.TabIndex = 3;
            this.cboFeature.Leave += new System.EventHandler(this.cboFeature_Leave);
            // 
            // pbFeature
            // 
            this.pbFeature.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbFeature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFeature.Location = new System.Drawing.Point(637, 37);
            this.pbFeature.Name = "pbFeature";
            this.pbFeature.Size = new System.Drawing.Size(100, 100);
            this.pbFeature.TabIndex = 7;
            this.pbFeature.TabStop = false;
            this.pbFeature.Visible = false;
            // 
            // gbSound
            // 
            this.gbSound.Controls.Add(this.label3);
            this.gbSound.Controls.Add(this.cboSound);
            this.gbSound.Controls.Add(this.pbSound);
            this.gbSound.Location = new System.Drawing.Point(468, 199);
            this.gbSound.Name = "gbSound";
            this.gbSound.Size = new System.Drawing.Size(802, 161);
            this.gbSound.TabIndex = 11;
            this.gbSound.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(585, 32);
            this.label3.TabIndex = 12;
            this.label3.Text = "Does the animal make the followimg sounds?";
            // 
            // cboSound
            // 
            this.cboSound.FormattingEnabled = true;
            this.cboSound.Items.AddRange(new object[] {
            ""});
            this.cboSound.Location = new System.Drawing.Point(22, 92);
            this.cboSound.Name = "cboSound";
            this.cboSound.Size = new System.Drawing.Size(425, 39);
            this.cboSound.Sorted = true;
            this.cboSound.TabIndex = 4;
            this.cboSound.Leave += new System.EventHandler(this.cboSound_Leave);
            // 
            // pbSound
            // 
            this.pbSound.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbSound.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSound.Location = new System.Drawing.Point(641, 37);
            this.pbSound.Name = "pbSound";
            this.pbSound.Size = new System.Drawing.Size(100, 94);
            this.pbSound.TabIndex = 8;
            this.pbSound.TabStop = false;
            this.pbSound.Visible = false;
            // 
            // gbName
            // 
            this.gbName.Controls.Add(this.label4);
            this.gbName.Controls.Add(this.txtName);
            this.gbName.Controls.Add(this.pbName);
            this.gbName.Location = new System.Drawing.Point(468, 16);
            this.gbName.Name = "gbName";
            this.gbName.Size = new System.Drawing.Size(802, 161);
            this.gbName.TabIndex = 10;
            this.gbName.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(557, 32);
            this.label4.TabIndex = 12;
            this.label4.Text = "Does the animal have the followimg name?";
            // 
            // txtName
            // 
            this.txtName.Enabled = false;
            this.txtName.Location = new System.Drawing.Point(22, 97);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(425, 38);
            this.txtName.TabIndex = 5;
            // 
            // pbName
            // 
            this.pbName.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbName.Location = new System.Drawing.Point(641, 46);
            this.pbName.Name = "pbName";
            this.pbName.Size = new System.Drawing.Size(100, 89);
            this.pbName.TabIndex = 9;
            this.pbName.TabStop = false;
            this.pbName.Visible = false;
            // 
            // pnlControls
            // 
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.btnStart);
            this.pnlControls.Controls.Add(this.btnReset);
            this.pnlControls.Controls.Add(this.txtFocus);
            this.pnlControls.Controls.Add(this.btnClose);
            this.pnlControls.Controls.Add(this.btnAdd);
            this.pnlControls.Controls.Add(this.btnGuess);
            this.pnlControls.Location = new System.Drawing.Point(12, 797);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(782, 196);
            this.pnlControls.TabIndex = 1;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(177, 51);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(143, 84);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtFocus
            // 
            this.txtFocus.Location = new System.Drawing.Point(686, 55);
            this.txtFocus.Name = "txtFocus";
            this.txtFocus.Size = new System.Drawing.Size(68, 38);
            this.txtFocus.TabIndex = 2;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(453, 51);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(143, 84);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Enabled = false;
            this.btnAdd.Location = new System.Drawing.Point(319, 51);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(143, 84);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnGuess
            // 
            this.btnGuess.Location = new System.Drawing.Point(38, 51);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(143, 84);
            this.btnGuess.TabIndex = 1;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // pnlYesNo
            // 
            this.pnlYesNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlYesNo.Controls.Add(this.btnNo);
            this.pnlYesNo.Controls.Add(this.btnYes);
            this.pnlYesNo.Location = new System.Drawing.Point(800, 797);
            this.pnlYesNo.Name = "pnlYesNo";
            this.pnlYesNo.Size = new System.Drawing.Size(487, 196);
            this.pnlYesNo.TabIndex = 2;
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.Red;
            this.btnNo.Location = new System.Drawing.Point(230, 51);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(143, 80);
            this.btnNo.TabIndex = 1;
            this.btnNo.Text = "No";
            this.btnNo.UseVisualStyleBackColor = false;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // btnYes
            // 
            this.btnYes.BackColor = System.Drawing.Color.Lime;
            this.btnYes.Location = new System.Drawing.Point(22, 51);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(143, 80);
            this.btnYes.TabIndex = 0;
            this.btnYes.Text = "Yes";
            this.btnYes.UseVisualStyleBackColor = false;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(38, 137);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(558, 59);
            this.btnStart.TabIndex = 14;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1307, 1005);
            this.Controls.Add(this.pnlYesNo);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlAnimal);
            this.Name = "frmMain";
            this.Text = "Guess the Animal";
            this.pnlAnimal.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbColour)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFeature)).EndInit();
            this.gbSound.ResumeLayout(false);
            this.gbSound.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSound)).EndInit();
            this.gbName.ResumeLayout(false);
            this.gbName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbName)).EndInit();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlYesNo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAnimal;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Panel pnlYesNo;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboColour;
        private System.Windows.Forms.PictureBox pbColour;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboFeature;
        private System.Windows.Forms.PictureBox pbFeature;
        private System.Windows.Forms.GroupBox gbSound;
        private System.Windows.Forms.ComboBox cboSound;
        private System.Windows.Forms.PictureBox pbSound;
        private System.Windows.Forms.GroupBox gbName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.PictureBox pbName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbAnimals;
        private System.Windows.Forms.TextBox txtFocus;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnStart;
    }
}

