﻿This program contains the following:

To Play "Guess the Animal":
	1) The user will choose an animal from the list on the left of the screen
	2) The Sound field will be available for the application to guess what sound the animal you have chosen would make.
	3) The user should respond with a yes or no to whether the chosen animal makes that sound.
		If Yes the screen will move to the next field to make a guess.
		If No then the application will make another guess.

To Clear the screen for another guess:
	1) Click Guess button

To Add an animal to the application:
	1) Click Reset button
	2) Add details to the name, sound, feature and colour by typing in the field. Should item already exist then this will not be added.
	3) Click Add button

To Close the application:
	1) Click on Close button

Test Case
1) Select "Roars" from sound drop down / Select "Yes"
2) Select "Whiskers" from feature drop down / Select Yes
3) Select "Spotted" from the colour dropdown / Select Yes